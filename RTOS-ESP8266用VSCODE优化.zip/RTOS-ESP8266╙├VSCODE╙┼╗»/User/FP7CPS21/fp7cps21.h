#ifndef FP7CPS21_H
#define FP7CPS21_H

#include "stm32f10x.h"

#define CPS21_BUF_LEN 128

extern char cps21_rx_buf[CPS21_BUF_LEN];
void uart3_Init(u32 bound);
void USART3_DMA_Config(void);
void Uart3_DMA_Rx_Data(void);
//void USART3_IRQHandler(void);
#endif
