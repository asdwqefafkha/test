#ifndef FP_XH_C60T_H
#define FP_XH_C60T_H

#include "stm32f10x.h"

#define C60T_BUF_LEN 128

extern char c60t_rx_buf[C60T_BUF_LEN];
void uart4_Init(u32 bound);
void USART4_DMA_Config(void);
void Uart4_DMA_Rx_Data(void);
//void UART4_IRQHandler(void);
#endif
