#include "tcp.h"
#include "bsp_usart.h"
#include "esp8266.h"
#include "delay.h"
#include "stdio.h"
#include "string.h"
#include "stm32f10x.h"
#include "bsp_rtc.h"
char macbuf[64]={0};
char sysTime2[25]={0}; 
char sysTime1[25]={0};
extern struct rtc_time systmtime;
void extractTime(char *response) {


    // ���Ҳ���ȡsysTime2��ʱ��
    char *ptr2 = strstr(response, "\"sysTime2\":\"");
    if (ptr2!= NULL) {
        ptr2 += strlen("\"sysTime2\":\"");
        int i = 0;
        while (*ptr2!= '"' && i < sizeof(sysTime2) - 1) {
            sysTime2[i++] = *ptr2++;
        }
        sysTime2[i] = '\0';
        printf("\nsysTime2: %s\n", sysTime2);
    }

    // ���Ҳ���ȡsysTime1��ʱ��
    char *ptr1 = strstr(response, "\"sysTime1\":\"");
    if (ptr1!= NULL) {
        ptr1 += strlen("\"sysTime1\":\"");
        int j = 0;
        while (*ptr1!= '"' && j < sizeof(sysTime1) - 1) {
            sysTime1[j++] = *ptr1++;
        }
        sysTime1[j] = '\0';
        printf("sysTime1: %s\n", sysTime1);
    }

}

void ESP8266_STA_TCPClient_Test(void)
{
	ESP8266_Rst();
    ESP8266_AT_Test();
	printf("��������ESP8266\r\n");
    ESP8266_Net_Mode_Choose(STA);
    while(!ESP8266_JoinAP(User_ESP8266_SSID, User_ESP8266_PWD));
    ESP8266_Enable_MultipleId ( DISABLE );

	while(!ESP8266_Link_Server(enumTCP, "quan.suning.com", "80", Single_ID_0));
	
	while(!ESP8266_UnvarnishSend());
	printf("\r\n�������\n");
	while (strncmp(ESP8266_Fram_Record_Struct.Data_RX_BUF, "HTTP/1.1 200", 12)!= 0)
	{
		memset(ESP8266_Fram_Record_Struct.Data_RX_BUF,0,RX_BUF_MAX_LEN);
		ESP8266_Fram_Record_Struct .InfBit .FramLength = 0;
		ESP8266_Fram_Record_Struct.InfBit.FramFinishFlag=0;
		ESP8266_SendString ( ENABLE,"GET /getSysTime.do HTTP/1.1\r\nHost: quan.suning.com\r\nConnection: keep-alive\r\n\r\n",0, Single_ID_0 );
		while(!ESP8266_Fram_Record_Struct.InfBit.FramFinishFlag);
	
	}
	//while(!ESP8266_Fram_Record_Struct.InfBit.FramFinishFlag);
	extractTime(ESP8266_Fram_Record_Struct.Data_RX_BUF);
					struct rtc_time set_time;

				/*ʹ�ô��ڽ������õ�ʱ�䣬��������ʱע��ĩβҪ�ӻس�*/
				Time_Regulate_Get_c(&set_time,sysTime2);
				/*�ý��յ���ʱ������RTC*/
				Time_Adjust(&set_time);
	Time_Display( RTC_GetCounter(),&systmtime);
	delay_ms(5000);
	ESP8266_Rst();
	ESP8266_AT_Test();
	printf("��������ESP8266\r\n");
    ESP8266_Net_Mode_Choose(STA);
    while(!ESP8266_JoinAP(User_ESP8266_SSID, User_ESP8266_PWD));
    ESP8266_Enable_MultipleId ( DISABLE );
    while(!ESP8266_Link_Server(enumTCP, User_ESP8266_TCPServer_IP, User_ESP8266_TCPServer_PORT, Single_ID_0));

	get_mac_wifi(macbuf);//��ȡMAC��ַ

    while(!ESP8266_UnvarnishSend());
	printf("\r\n�������\n");
	clear_esp8266recvbuf();
}
