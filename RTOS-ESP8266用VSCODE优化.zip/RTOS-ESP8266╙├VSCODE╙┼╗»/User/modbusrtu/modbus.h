#ifndef MODBUS_H
#define MODBUS_H

#include "stm32f10x.h"

#define RX_BUF_LEN 64
#define MERAGE2(h,l) ((((uint16_t)h) << 8) | l)
#define MERAGE4(one,two,three,four)	(((uint32_t)one << 24) | ((uint32_t)two << 16) | ((uint16_t)three << 8) | four)

typedef struct {
    uint16_t voltage;     // ��ѹ
    uint32_t current;     // ����
    uint32_t power;       // ����
    uint32_t energy;      // ����
    uint16_t frequency;   // Ƶ��
    uint16_t power_factor;// ��������
    uint16_t alarm_status;// ����״̬
} MeasurementData;

//extern uint8_t rx_buffer[RX_BUF_LEN];
extern volatile MeasurementData data;


uint16_t crc16(const uint8_t *data, uint16_t length);
void parseAndPrintData(void);
// Modbus RTUͨ��
void Modbus_Communicate(uint8_t command) ;
void uart5_Init(u32 bound);

#endif
